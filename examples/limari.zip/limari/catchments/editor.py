import shapefile 

input = shapefile.Reader("./Capa_Catchment.shp")
type_geometry= input.shapeType # -> the type of geometry
w = shapefile.Writer("./Capa_Catchment2.shp")
fields = input.fields[1:] # -> the fields definition in a list

for name in fields:
    if type(name) == "tuple":
        continue
    else:
        args = name
        w.field(*args)

records = input.records()
for row in records:
    args = row
    w.record(*args)
shapes = input.shapes() # -> the geometries in a list

for shape in shapes:
    w.shape(shape)

w._bbox = [239001.5, 6519998.2999, 388101.5, 6659198.29]

w.close()